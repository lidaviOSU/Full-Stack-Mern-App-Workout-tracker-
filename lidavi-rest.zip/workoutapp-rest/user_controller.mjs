import * as excercise from './user_model.mjs';
import express from 'express';
const app = express();

const PORT = 3000;

app.use(express.json());


/**
 * Create a exercise with name, reps, weight, units, and date provided in the query parameters
 */
app.post("/exercises", (req, res) => {
    excercise.createexcercise(req.body.name, req.body.reps, req.body.weight, req.body.unit, req.body.date)
        .then(excercise => {
            res.status(201).json(excercise);
        })
        .catch(error => {
            console.error(error);
            res.status(500).json({ Error: 'Request failed' });
        });
});

/**
 * Retrive exercises. 
 * Has middlewar to check to retrieve requests and the updates variables for querys(0 or greater)
 */

app.get("/exercises", (req, res) => {
    let filter = {}
        excercise.findexcercise(filter, '', 0)
        .then(excercise => {
            console.log(excercise)
            res.status(200).json(excercise);
        })
        .catch(error => {
            console.error(error);
            res.status(500).send({ error: 'Not found' });
        });

});

/**
 * Update the exercise whose _id is provided and set its name, reps, weight, units, date to
 * the values provided in the query parameters
 */
app.put('/exercises/:_id', (req, res) => {
    excercise.updateexcercise(req.params._id, req.body.name, req.body.reps, req.body.weight, req.body.unit, req.body.date)
        .then(modifiedCount => {
            if(modifiedCount === 1){
                res.json({ _id: req.params._id, name:req.body.name, reqs: req.body.reps, weight: req.body.weight, unit:req.body.unit, date:req.body.date });
            }else{
                res.status(500).json({ error: 'Not Found1' });
            }
        })
        .catch(error => {
            console.error(error);
            res.status(500).json({ error: 'Not Found2' });
        });
});

/**
 * Delete the exercises with the provided query parameters
 */
 app.delete('/exercises/:_id', (req, res) => {
    excercise.deleteByQuery(req.params._id)
        .then(deletedCount => {
            if (deletedCount === 1){
                res.status(204).send();
            } else{
                res.status(500).json({Error: 'Resource not found'});
            }
        })
        .catch(error => {
            console.error(error);
            res.status(500).send({ error: 'Request failed' });
        });
});

app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}...`);
});