// Get the mongoose object
import mongoose from 'mongoose';

// Prepare to the database exercise_db in the MongoDB server running locally on port 27017
mongoose.connect(
    'mongodb://localhost:27017/exercise_db',
    { useNewUrlParser: true }
);

// Connect to to the database
const db = mongoose.connection;

// The open event is called when the database connection successfully opens
db.once('open', () => {
    console.log('Successfully connected to MongoDB using Mongoose!');
});

/**
 * Define the schemas
 */
const excerciseSchema = mongoose.Schema({
    name: { type: String, required: true },
    reps: { type: Number, required: true },
    weight:{ type: Number, required: true },
    unit: { type: String, required: true },
    date: { type: String, required: true }
});

/**
 * Compile the model from the schema. This must be done after defining the schema.
 */
const excercise = mongoose.model("Excercise", excerciseSchema);
/**
 * Create a excercise
 * @param {String} name 
 * @param {Number} reps 
 * @param {Number} weight
 * @param {String} unit 
 * @param {String} date 
 * @returns A promise. Resolves to the JSON object for the document created by calling save
 */
const createexcercise = async (name, reps, weight, unit, date) => {
    // Call the constructor to create an instance of the model class Excercise
    const Excercise = new excercise({ name: name, reps: reps, weight: weight, unit: unit, date: date});
    // Call save to persist this object as a document in MongoDB
    return Excercise.save();
}

/**
 * Retrive user based on the filter, projection and limit parameters
 * @param {Object} filter 
 * @param {String} projection 
 * @param {Number} limit 
 * @returns 
 */
const findexcercise = async (filter, projection, limit) => {
    const query = excercise.find(filter)
        .select(projection)
        .limit(limit);
        if(filter.length > 0){
            query.and(filters);
          }
    return query.exec();
}

/**
 * Replace the name, reps, weight, unit, and date of the user with the id value provided
 * @param {String} _id 
 * @param {String} name 
 * @param {Number} reps 
 * @param {Number} weight
 * @param {String} unit 
 * @param {String} date 
 * @returns A promise. Resolves to the number of documents modified
 */
const updateexcercise = async ( _id, name, reps, weight, unit, date) => {
    const result = await excercise.updateMany({ _id: _id }, { name: name, reps: reps, weight: weight, unit: unit, date: date});
    return result.modifiedCount;
}

/**
 * Delete the exercise with provided queries
 * @param {String} _id 
 * @param {String} name 
 * @param {Number} reps 
 * @param {Number} weight
 * @param {String} unit 
 * @param {String} date 
 * @returns A promise. Resolves to the count of deleted documents
 */
 const deleteByQuery = async ( _id, name, reps, weight, unit, date) => {
     if(_id === undefined && name === undefined && reps === undefined && weight === undefined && unit === undefined){
        const result = await excercise.deleteMany({ date:date});
        return result.deletedCount;
     }else if(_id === undefined && name === undefined && reps === undefined && weight === undefined && date === undefined){
        const result = await excercise.deleteMany({ unit: unit});
        return result.deletedCount;
     }else if(_id === undefined && name === undefined && reps === undefined && unit === undefined && date === undefined){
        const result = await excercise.deleteMany({ weight: weight});
        return result.deletedCount;
     }else if (_id === undefined && name === undefined && weight === undefined && unit === undefined && date === undefined){
        const result = await excercise.deleteMany({ reps: reps});
        return result.deletedCount;
     }else if( _id === undefined && weight === undefined && reps === undefined && unit === undefined && date === undefined){
        const result = await excercise.deleteMany({ name: name});
        return result.deletedCount;
     }else if( name === undefined && weight === undefined && reps === undefined && unit === undefined && date === undefined){
        const result = await excercise.deleteMany({ _id: _id});
        return result.deletedCount;
}};

export { createexcercise, findexcercise, updateexcercise, deleteByQuery };